﻿using SDG.Unturned;
using Thanking.Attributes;
using UnityEngine;

namespace Thanking.Variables
{
    public static class OptimizationVariables
    {
        public static Player MainPlayer;
        public static Camera MainCam;
    }
}
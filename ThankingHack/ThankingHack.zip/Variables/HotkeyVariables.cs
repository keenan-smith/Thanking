﻿using UnityEngine;

namespace Thanking.Variables
{
    public class Hotkey
    {
        public string Name;
        public KeyCode[] Keys;
    }
}
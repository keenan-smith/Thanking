﻿using System;

namespace Thanking.Attributes
{
    /// <summary>
    /// Config save field
    /// </summary>
    [AttributeUsage(AttributeTargets.Field)]
    public class SaveAttribute : Attribute
    {
        
    }
}
﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using Thanking.Attributes;
using Thanking.Managers.Submanagers;
using Thanking.Utilities;

namespace Thanking.Managers.Main
{
    public static class AttributeManager
    {
        public static void Init()
        {
	        #if DEBUG
			DebugUtilities.Log("Initializing attribute manager...");
            #endif

            // Declare lists to be populated later
            List<Type> Components = new List<Type>();
            List<MethodInfo> Pre = new List<MethodInfo>();
            List<MethodInfo> Post = new List<MethodInfo>();
            
            foreach (Type T in Assembly.GetExecutingAssembly().GetTypes())
            {
                // Collect and add components marked with the attribute
                if (T.IsDefined(typeof(ComponentAttribute), false))
                    Loader.HookObject.AddComponent(T);

                // Collect components to be destroyed on spy
                if (T.IsDefined(typeof(SpyComponentAttribute), false))
                    Components.Add(T);

                foreach (MethodInfo M in T.GetMethods())
                {
                    // Collect and invoke methods marked to be initialized
                    if (M.IsDefined(typeof(InitializerAttribute), false))
                        M.Invoke(null, null);

                    // Collect and override methods marked with the attribute
                    if (M.IsDefined(typeof(OverrideAttribute), false))
                        OverrideManager.LoadOverride(M);

                    // Collect methods to be invoked before spy
                    if (M.IsDefined(typeof(OnSpyAttribute), false))
                        Pre.Add(M);

                    // Collect methods to be invoked after spy
                    if (M.IsDefined(typeof(OffSpyAttribute), false))
                        Post.Add(M);

                    // Collect and thread methods marked with the attribute
                    if (M.IsDefined(typeof(ThreadAttribute), false))
                        new Thread(new ThreadStart((Action) Delegate.CreateDelegate(typeof(Action), M))).Start();
                }
            }
            
            // Assign all variables
            SpyManager.Components = Components;
            SpyManager.PostSpy = Post;
            SpyManager.PreSpy = Pre;
        }
    }
}

﻿using Thanking.Attributes;

namespace Thanking.Options.VisualOptions
{
    public static class MirrorCameraOptions
    {
        [Save] public static bool Enabled = false;
    }
}

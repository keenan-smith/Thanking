﻿namespace ThankingObfuscator.Protection.MethodObfuscation
{
	public static class FakeAttributes
	{
	}
}

﻿﻿namespace ThankingObfuscator.Renaming
{
    class NamespaceTypeStore
    {

        public string TypeName { get; set; }
        public string NamespaceName { get; set; }


    }
}

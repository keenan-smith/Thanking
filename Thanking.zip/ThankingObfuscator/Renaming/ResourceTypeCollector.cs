﻿using dnlib.DotNet;

namespace ThankingObfuscator.Renaming
{
    class ResourceTypeCollector
    {

        public TypeDef Type { get; set; }
        public EmbeddedResource Resource { get; set; }


    }
}
